// Dutch Ink Studio starter site settings.
// IMPORTANT: replace the placeholder WhatsApp number with your real number.
// Use international format without +, spaces or brackets, e.g. 31612345678.
const STUDIO_WHATSAPP_NUMBER = "REPLACE_WITH_YOUR_NUMBER";

const translations = {
  en: {
    announcement:"Custom tattoos • Appointment only • The Netherlands",navGallery:"Gallery",navAbout:"Our approach",navBooking:"Booking",navContact:"Contact",bookNow:"Book now",
    heroEyebrow:"CUSTOM TATTOO STUDIO · THE NETHERLANDS",heroTitle:'Your story.<br><em>Written in ink.</em>',heroIntro:"Thoughtful custom tattoos, crafted with care, precision and individuality.",heroCta:"Request an appointment",heroGallery:"Explore the gallery",heroNote:"By appointment · Personal designs · Clear aftercare",introLine:"GOOD TATTOOS MEAN SOMETHING.",introLine2:"MADE WITH INTENTION. WORN FOR LIFE.",
    galleryEyebrow:"THE PORTFOLIO",galleryTitle:'A little <em>inspiration.</em>',galleryIntro:"Explore a few style directions. Replace these sample images with your own work before launch.",styleOne:"Fine line",styleTwo:"Blackwork",styleThree:"Custom pieces",styleFour:"Meaningful symbols",imageNote:"Portfolio preview images are illustrative. Only show work you have permission to use.",
    aboutEyebrow:"THE DUTCH INK APPROACH",aboutTitle:'Made for you.<br><em>Never off the shelf.</em>',aboutText:"Every tattoo begins with a conversation. Tell us the idea, placement and feeling you want to capture. We’ll discuss the design, practical details and aftercare before confirming your session.",valueOneTitle:"Personal design",valueOneText:"A concept shaped around your idea.",valueTwoTitle:"Care first",valueTwoText:"Clear hygiene and aftercare information.",valueThreeTitle:"No surprises",valueThreeText:"Discuss price and timing before confirmation.",aboutCta:"Tell us your idea",
    bookingEyebrow:"START YOUR PROJECT",bookingTitle:'Let’s make it <em>real.</em>',bookingText:"Share a few details about the tattoo you have in mind. This form opens a prepared WhatsApp message so we can discuss your request. Your appointment is not confirmed until we reply.",bookingPoint1:"Send references or inspiration",bookingPoint2:"Discuss availability and pricing",bookingPoint3:"Confirm details before paying a deposit",formTitle:"APPOINTMENT REQUEST",labelName:"Your name",labelEmail:"Email (optional)",labelStyle:"Tattoo style",chooseStyle:"Choose a style",labelPlacement:"Body placement",labelSize:"Approx. size",labelDate:"Preferred date (optional)",labelDetails:"Tell us about your idea",consentText:"I agree to send these details to Dutch Ink Studio via WhatsApp to discuss my request.",sendRequest:"Send request on WhatsApp",formFootnote:"No payment is taken by this form. Please do not send sensitive personal information.",
    depositEyebrow:"DEPOSITS & CONFIRMATION",depositTitle:'Clear terms. <em>Secure booking.</em>',depositText:"Deposits can be arranged after we agree on your design, price and appointment. This demo does not collect payments. Add a verified payment provider and publish clear cancellation and refund terms before accepting money.",depositCta:"Ask about deposits",contactEyebrow:"GET IN TOUCH",contactTitle:'Your idea starts <em>here.</em>',contactWhatsApp:"WHATSAPP",contactWhatsAppValue:"Set your studio number in the website settings.",contactLocation:"LOCATION",contactLocationValue:"The Netherlands · By appointment",contactHours:"OPENING",contactHoursValue:"Appointment only",whatsappCta:"Message us on WhatsApp",footerLine:"Custom work. Personal meaning. Made with care.",footerBooking:"Booking",footerContact:"Contact",footerRights:"All rights reserved."
  },
  nl: {
    announcement:"Tattoos op maat • Alleen op afspraak • Nederland",navGallery:"Galerij",navAbout:"Onze werkwijze",navBooking:"Afspraak",navContact:"Contact",bookNow:"Boek nu",
    heroEyebrow:"TATTOOSTUDIO OP MAAT · NEDERLAND",heroTitle:'Jouw verhaal.<br><em>In inkt vereeuwigd.</em>',heroIntro:"Persoonlijke tattoos op maat, met zorg, precisie en oog voor jouw individualiteit.",heroCta:"Afspraak aanvragen",heroGallery:"Bekijk de galerij",heroNote:"Op afspraak · Persoonlijke ontwerpen · Duidelijke nazorg",introLine:"GOEDE TATTOOS BETEKENEN IETS.",introLine2:"MET AANDACHT GEMAAKT. VOOR HET LEVEN.",
    galleryEyebrow:"HET PORTFOLIO",galleryTitle:'Een beetje <em>inspiratie.</em>',galleryIntro:"Bekijk enkele stijlrichtingen. Vervang deze voorbeeldafbeeldingen vóór de lancering door eigen werk.",styleOne:"Fine line",styleTwo:"Blackwork",styleThree:"Unieke ontwerpen",styleFour:"Betekenisvolle symbolen",imageNote:"De voorbeeldafbeeldingen zijn ter illustratie. Gebruik alleen werk waarvoor je toestemming hebt.",
    aboutEyebrow:"DE DUTCH INK-WERKWIJZE",aboutTitle:'Voor jou gemaakt.<br><em>Nooit standaard.</em>',aboutText:"Elke tattoo begint met een gesprek. Vertel ons over je idee, de plaatsing en het gevoel dat je wilt vastleggen. We bespreken het ontwerp, de praktische details en de nazorg voordat we je afspraak bevestigen.",valueOneTitle:"Persoonlijk ontwerp",valueOneText:"Een concept dat bij jouw idee past.",valueTwoTitle:"Zorg staat voorop",valueTwoText:"Duidelijke informatie over hygiëne en nazorg.",valueThreeTitle:"Geen verrassingen",valueThreeText:"Bespreek prijs en planning vooraf.",aboutCta:"Vertel ons je idee",
    bookingEyebrow:"START JE PROJECT",bookingTitle:'Laten we het <em>echt maken.</em>',bookingText:"Deel een paar details over de tattoo die je in gedachten hebt. Dit formulier opent een vooraf ingevuld WhatsApp-bericht zodat we je aanvraag kunnen bespreken. Je afspraak is pas bevestigd nadat we reageren.",bookingPoint1:"Stuur voorbeelden of inspiratie",bookingPoint2:"Bespreek beschikbaarheid en prijzen",bookingPoint3:"Bevestig de details vóór een aanbetaling",formTitle:"AFSPRAAKAANVRAAG",labelName:"Je naam",labelEmail:"E-mail (optioneel)",labelStyle:"Tattoo-stijl",chooseStyle:"Kies een stijl",labelPlacement:"Plaats op het lichaam",labelSize:"Geschatte grootte",labelDate:"Gewenste datum (optioneel)",labelDetails:"Vertel over je idee",consentText:"Ik ga ermee akkoord deze gegevens via WhatsApp naar Dutch Ink Studio te sturen om mijn aanvraag te bespreken.",sendRequest:"Aanvraag via WhatsApp versturen",formFootnote:"Via dit formulier wordt geen betaling uitgevoerd. Stuur geen gevoelige persoonsgegevens.",
    depositEyebrow:"AANBETALING & BEVESTIGING",depositTitle:'Duidelijke afspraken. <em>Veilig boeken.</em>',depositText:"Een aanbetaling kan worden geregeld nadat we het ontwerp, de prijs en de afspraak hebben afgesproken. Deze demoversie verwerkt geen betalingen. Voeg een geverifieerde betaaldienst toe en publiceer duidelijke annulerings- en terugbetalingsvoorwaarden voordat je geld aanneemt.",depositCta:"Vraag naar aanbetalingen",contactEyebrow:"NEEM CONTACT OP",contactTitle:'Jouw idee begint <em>hier.</em>',contactWhatsApp:"WHATSAPP",contactWhatsAppValue:"Vul je studionummer in bij de website-instellingen.",contactLocation:"LOCATIE",contactLocationValue:"Nederland · Op afspraak",contactHours:"OPENINGSTIJDEN",contactHoursValue:"Alleen op afspraak",whatsappCta:"Stuur ons een WhatsApp",footerLine:"Uniek werk. Persoonlijke betekenis. Met zorg gemaakt.",footerBooking:"Afspraak",footerContact:"Contact",footerRights:"Alle rechten voorbehouden."
  }
};
let currentLanguage = "en";
const languageToggle = document.getElementById("languageToggle");
function setLanguage(language) {
  currentLanguage = language;
  document.documentElement.lang = language;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (translations[language][key]) el.innerHTML = translations[language][key];
  });
  languageToggle.textContent = language === "en" ? "NL" : "EN";
}
languageToggle.addEventListener("click", () => setLanguage(currentLanguage === "en" ? "nl" : "en"));

const menuToggle = document.getElementById("menuToggle");
menuToggle.addEventListener("click", () => {
  const open = document.body.classList.toggle("menu-open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "×" : "☰";
});
document.querySelectorAll(".desktop-nav a").forEach(a => a.addEventListener("click", () => {
  document.body.classList.remove("menu-open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

function whatsappUrl(message) {
  if (!/^\d{8,15}$/.test(STUDIO_WHATSAPP_NUMBER)) {
    alert("The website owner must first add a real WhatsApp number in script.js. Replace REPLACE_WITH_YOUR_NUMBER with your international number, digits only.");
    return null;
  }
  return `https://wa.me/${STUDIO_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
document.getElementById("bookingForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const message = [
    "Hello Dutch Ink Studio! I'd like to request a tattoo appointment.",
    `Name: ${form.get("fullName")}`,
    `Email: ${form.get("email") || "Not provided"}`,
    `Style: ${form.get("service")}`,
    `Placement: ${form.get("placement") || "Not specified"}`,
    `Approximate size: ${form.get("size") || "Not specified"}`,
    `Preferred date: ${form.get("date") || "Flexible"}`,
    `Idea: ${form.get("details")}`
  ].join("\n");
  const url = whatsappUrl(message);
  if (url) window.open(url, "_blank", "noopener,noreferrer");
});
const contactButton = document.getElementById("contactWhatsAppButton");
contactButton.addEventListener("click", event => {
  event.preventDefault();
  const url = whatsappUrl("Hello Dutch Ink Studio! I'd like to ask a question about a tattoo.");
  if (url) window.open(url, "_blank", "noopener,noreferrer");
});
document.getElementById("year").textContent = new Date().getFullYear();
