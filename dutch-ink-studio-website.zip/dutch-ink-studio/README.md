# Dutch Ink Studio — website starter

A responsive black-and-gold tattoo studio website with:
- English / Dutch language toggle
- Tattoo gallery (sample external images)
- Appointment request form that opens a pre-filled WhatsApp message
- WhatsApp contact link
- Deposit information section (payments are **not** implemented)
- Mobile navigation

## Files
- `index.html` — page structure
- `styles.css` — responsive styling
- `script.js` — language toggle, WhatsApp settings and form behavior

## Before you publish
1. Open `script.js`.
2. Replace `REPLACE_WITH_YOUR_NUMBER` with your WhatsApp number in international digits-only format. Example format: `31612345678` (do not use this example number).
3. Replace the sample gallery and hero image URLs with photos you own or have permission to use.
4. Update the location, business details and legal/contact information to match your actual business.
5. Test the booking form and the language switch on a phone and desktop.

## Free hosting with GitHub Pages
1. Create or sign in to a GitHub account at https://github.com.
2. Create a new **public** repository named `dutch-ink-studio`.
3. Upload `index.html`, `styles.css`, and `script.js` to the repository's root (top level).
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main`, folder `/ (root)`, then save.
7. Wait for GitHub Pages to publish. Your site URL will normally be:
   `https://YOUR-GITHUB-USERNAME.github.io/dutch-ink-studio/`
   Replace `YOUR-GITHUB-USERNAME` with your own GitHub username.
8. Open the published URL and test the page and booking form.

## Online deposits
This starter does not take or store payments. Do not collect card details in this site. To accept deposits later, create a merchant account with a supported payment provider (for example, Mollie or Stripe, subject to their approval and availability), then use its hosted checkout/payment links or a secure integration. Set your deposit, cancellation, rescheduling and refund terms clearly before taking payment. Never treat a WhatsApp enquiry as a confirmed appointment.

## Important
This website is a front-end starter, not a full booking database. Form submissions are sent to WhatsApp and are not stored in an admin panel. A physical tattoo studio in the Netherlands must meet applicable GGD permit and hygiene requirements before tattooing clients. Check that you are legally allowed to run a business in the Netherlands before opening.
